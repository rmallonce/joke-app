import React from "react";
import { ReactDOM } from "react";
import Search from "./Search";

export default function App(){

    
   

    return(

        <>

            <Search />
            
        
        </>

    )

}
